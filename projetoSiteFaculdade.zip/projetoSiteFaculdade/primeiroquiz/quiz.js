let currentQuestion = 1;
const totalQuestions = 10;
let correctAnswers = 0;
let totalAnswers = 0;
const answers = {}; // Objeto para armazenar as respostas corretas
const attemptCounts = {}; // Objeto para armazenar as tentativas de cada pergunta

// Função para iniciar o Quiz
function startQuiz() {
    document.getElementById('intro-modal').style.display = 'none'; // Esconde o modal
    showQuestion('question1'); // Mostra a primeira pergunta
}

// Função para mostrar uma pergunta específica
function showQuestion(questionId) {
    const questions = document.querySelectorAll('.quiz-container');
    questions.forEach(question => {
        question.style.display = 'none';
    });
    document.getElementById(questionId).style.display = 'block';
    
    // Inicializa o contador de tentativas para a pergunta atual
    if (!attemptCounts[questionId]) {
        attemptCounts[questionId] = 0;
    }
}

// Função para enviar uma resposta e verificar se está correta
function submitQuiz(currentQuestionId, correctAnswer) {
    const options = document.querySelector(`input[name="${currentQuestionId}"]:checked`);
    
    if (options) {
        attemptCounts[currentQuestionId]++;
        totalAnswers++;
        
        const questionContainer = document.getElementById(currentQuestionId);
        
        if (options.value === correctAnswer) {
            correctAnswers++;
            questionContainer.classList.add('correct');
            questionContainer.classList.remove('incorrect');
            answers[currentQuestionId] = true;
            if (currentQuestion < totalQuestions) {
                currentQuestion++;
                showQuestion(`question${currentQuestion}`);
            } else {
                showResult();
            }
        } else {
            questionContainer.classList.add('incorrect');
            questionContainer.classList.remove('correct');
            answers[currentQuestionId] = false;
            if (attemptCounts[currentQuestionId] >= 3) {
                questionContainer.innerHTML += `<p class="error-message">Você atingiu o número máximo de tentativas para esta pergunta.</p>`;
                if (currentQuestion < totalQuestions) {
                    currentQuestion++;
                    showQuestion(`question${currentQuestion}`);
                } else {
                    showResult();
                }
            }
        }
    } else {
        alert('Por favor, selecione uma resposta.');
    }
}

// Função para mostrar o resultado do quiz
function showResult() {
    const questions = document.querySelectorAll('.quiz-container');
    questions.forEach(question => {
        question.style.display = 'none';
    });

    const resultDiv = document.getElementById('result');
    resultDiv.style.display = 'flex';
    resultDiv.style.alignItems = 'center';
    resultDiv.style.justifyContent = 'center';

    const resultText = document.getElementById('result-text');
    const resultContainer = document.getElementById('result-container');
    
    // Limpa o conteúdo do resultContainer antes de adicionar novo conteúdo
    resultContainer.innerHTML = '';

    if (correctAnswers === totalQuestions) {
        resultText.textContent = `Parabéns meu amor, você conseguiu provar que é realmente a minha mulher, acertando todas as ${totalQuestions} perguntas!`;
        resultContainer.innerHTML = `<p>Como eu achei isso divertido, vamos tentar mais uma vez, mas dessa vez, você quem irá fazer um quiz para mim!</p>`;
        
    } else {
        resultText.textContent = `Você acertou ${correctAnswers} de ${totalQuestions} perguntas, mas tá tudo bem, minha princesa.`;
        resultContainer.innerHTML = `<p>Você não acertou todas, mas tudo bem, eu confio em você (até porque eu tô do seu lado agora e sei que é você quem está fazendo esse desafio), então dessa vez, você quem vai criar um quiz para mim, meu amor.</p>`;
        
        
    }

    const showErrorsBtn = document.getElementById('show-errors-btn');
    if (Object.values(answers).includes(false)) {
        showErrorsBtn.style.display = 'block'; // Mostra o botão apenas se houver perguntas erradas
    }
}

// Função para mostrar as perguntas erradas
function showErrors() {
    const resultContainer = document.getElementById('result-container');
    resultContainer.innerHTML = ''; // Limpa o conteúdo atual

    const questions = document.querySelectorAll('.quiz-container');
    questions.forEach(question => {
        const questionId = question.id;
        if (answers[questionId] === false) { // Exibe apenas as perguntas incorretas
            const questionClone = question.cloneNode(true);
            questionClone.style.display = 'block';
            questionClone.classList.add('incorrect');
            questionClone.classList.remove('correct');
            resultContainer.appendChild(questionClone);
        }
    });
}

window.onload = function() {
    document.getElementById('intro-modal').style.display = 'flex'; // Mostra o modal de introdução ao carregar a página
};
