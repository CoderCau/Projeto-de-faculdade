document.getElementById('add-question').addEventListener('click', addQuestion);
document.getElementById('create-quiz').addEventListener('click', createQuiz);

let quizData = {
    title: '',
    questions: [],
    currentQuestionIndex: 0,
    attemptsLeft: 0,
};

function addQuestion() {
    const questionCount = document.querySelectorAll('.question').length + 1;
    const questionContainer = document.getElementById('questions-container');

    const newQuestion = document.createElement('div');
    newQuestion.classList.add('question');
    newQuestion.innerHTML = `
        <h2>Questão ${questionCount}</h2>
        <label>Nome da Questão:</label>
        <input type="text" class="question-text" required>
        <label>Alternativas:</label>
        <div class="alternatives">
            <input type="text" class="alternative" placeholder="Alternativa A" required>
            <input type="text" class="alternative" placeholder="Alternativa B" required>
            <input type="text" class="alternative" placeholder="Alternativa C" required>
            <input type="text" class="alternative" placeholder="Alternativa D" required>
        </div>
        <label>Resposta Correta (A, B, C, D):</label>
        <input type="text" class="correct-answer" maxlength="1" required>
        <label>Tentativas Permitidas:</label>
        <input type="number" class="attempts" min="1" value="1" required>
    `;
    questionContainer.appendChild(newQuestion);
}

function createQuiz(event) {
    event.preventDefault();

    const quizName = document.getElementById('quiz-name').value;
    const questions = document.querySelectorAll('.question');

    quizData.title = quizName;
    quizData.questions = [];

    questions.forEach((question) => {
        const questionText = question.querySelector('.question-text').value;
        const alternatives = Array.from(question.querySelectorAll('.alternative')).map(input => input.value);
        const correctAnswer = question.querySelector('.correct-answer').value.toUpperCase();
        const attempts = parseInt(question.querySelector('.attempts').value, 10);

        quizData.questions.push({
            text: questionText,
            alternatives: alternatives,
            correctAnswer: correctAnswer,
            attemptsLeft: attempts,
        });
    });

    document.querySelector('.container').style.display = 'none';
    document.getElementById('quiz-container').style.display = 'block';

    startQuiz();
}

function startQuiz() {
    displayQuestion();
}

function displayQuestion() {
    const currentQuestion = quizData.questions[quizData.currentQuestionIndex];
    document.getElementById('quiz-title').textContent = quizData.title;
    document.getElementById('question-text').textContent = currentQuestion.text;
    document.getElementById('attempts-left').textContent = `Tentativas restantes: ${currentQuestion.attemptsLeft}`;

    const optionsContainer = document.getElementById('options');
    optionsContainer.innerHTML = '';

    currentQuestion.alternatives.forEach((alternative, index) => {
        const option = document.createElement('div');
        option.classList.add('option');
        option.textContent = `${String.fromCharCode(65 + index)}: ${alternative}`;
        option.addEventListener('click', () => checkAnswer(option, String.fromCharCode(65 + index)));
        optionsContainer.appendChild(option);
    });

    const submitButton = document.getElementById('submit-answer');
    submitButton.textContent = quizData.currentQuestionIndex < quizData.questions.length - 1
        ? 'Próxima Questão'
        : 'Finalizar Quiz';
    submitButton.onclick = moveToNextQuestion;
}

function checkAnswer(option, chosenAnswer) {
    const currentQuestion = quizData.questions[quizData.currentQuestionIndex];

    if (chosenAnswer === currentQuestion.correctAnswer) {
        option.classList.add('correct');
        document.getElementById('submit-answer').disabled = false;
    } else {
        option.classList.add('incorrect');
        currentQuestion.attemptsLeft--;
        document.getElementById('attempts-left').textContent = `Tentativas restantes: ${currentQuestion.attemptsLeft}`;
        if (currentQuestion.attemptsLeft <= 0) {
            alert('Você atingiu o limite de tentativas! Reiniciando o quiz.');
            restartQuiz();
        }
    }
}

function moveToNextQuestion() {
    if (quizData.currentQuestionIndex < quizData.questions.length - 1) {
        quizData.currentQuestionIndex++;
        displayQuestion();
    } else {
        finishQuiz();
    }
}

function restartQuiz() {
    quizData.currentQuestionIndex = 0;
    quizData.questions.forEach(q => (q.attemptsLeft = parseInt(q.attemptsLeft, 10)));
    displayQuestion();
}

function finishQuiz() {
  document.querySelector('.quiz-container').style.display = 'none';
  document.getElementById('final-message').style.display = 'block';
}

