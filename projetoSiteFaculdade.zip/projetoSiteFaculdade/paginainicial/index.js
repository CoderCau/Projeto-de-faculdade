var movimentoAtivo = true;
var numeroDeCliques = 0;
var tentativasErradas = 0;
var escolhaFeita = false;
var mensagemAtual = 0; // Começa pela primeira mensagem
 
 
// Função para mostrar ou ocultar mensagens com base no índice
function mudarMensagem(direcao) {
    var mensagens = document.querySelectorAll(".mensagem");
    if (mensagemAtual >= 0 && mensagemAtual < mensagens.length) {
        mensagens[mensagemAtual].style.display = "none"; // Oculta a mensagem atual
    }
 
 
    mensagemAtual += direcao; // Avança ou retrocede na lista de mensagens
 
 
    if (mensagemAtual >= mensagens.length) {
        mensagemAtual = mensagens.length - 1; // Garante que não ultrapasse o número de mensagens
    } else if (mensagemAtual < 0) {
        mensagemAtual = 0; // Garante que não vá abaixo do índice 0
    }
 
 
    mensagens[mensagemAtual].style.display = "block"; // Exibe a nova mensagem
 
 
    // Atualiza a visibilidade dos botões
    document.getElementById("btnRetornar").style.display = mensagemAtual > 0 ? "inline-block" : "none";
    document.getElementById("btnAvancar").style.display = mensagemAtual < mensagens.length - 1 ? "inline-block" : "none";
}
 
 
// Função que inicia o movimento do botão
function mostrarBrincadeira() {
    var botaoMovimento = document.getElementById('btnContinuar');
    botaoMovimento.onclick = function() {
        pararMovimento(); // Define a ação do botão para parar o movimento (ou seja, mover o botão)
    };
    moverBotao(); // Começa o movimento do botão
}
 
 
// Função que move o botão para uma posição aleatória na tela
function moverBotao() {
    if (movimentoAtivo) {
        var botao = document.getElementById("btnContinuar");
        var novaPosicaoX = Math.random() * (window.innerWidth - botao.clientWidth);
        var novaPosicaoY = Math.random() * (window.innerHeight - botao.clientHeight);
botao.style.position = "absolute";
botao.style.left = novaPosicaoX + "px";
botao.style.top = novaPosicaoY + "px";
    }
}
 
 
// Função que controla o número de cliques e decide quando parar o movimento
function pararMovimento() {
    numeroDeCliques++;
    if (numeroDeCliques < 13) {
        moverBotao(); // Continua movendo o botão enquanto o número de cliques for menor que 13
    } else {
        movimentoAtivo = false; // Para o movimento ao atingir 13 cliques
        document.getElementById("mensagemFinal").style.display = "block";
        document.getElementById("mensagemFinalTexto").innerHTML = "<p>Brunna, sabendo do quanto eu te amo, eu quero te perguntar, você aceita se casar comigo?</p><button id='btnSim' onclick='escolha(\"sim\")'>Sim</button><button id='btnNao' onclick='escolha(\"nao\")'>Não</button>";
        document.getElementById("btnContinuar").style.display = "none";
    }
}
 
 
// Função para lidar com a escolha da resposta ao pedido
function escolha(opcao) {
    if (!escolhaFeita) {
        escolhaFeita = true;
        document.getElementById("btnSim").classList.add("disabled");
        document.getElementById("btnNao").classList.add("disabled");
 
 
        if (opcao === 'sim') {
            document.getElementById("mensagemFinalTexto").innerHTML = "<p>Mas antes, quero ter certeza de que é você, então coloque aqui seu nome completo para ver o que acontecerá</p>";
            document.getElementById("inputNome").style.display = "block";
        } else {
            document.getElementById("mensagemFinalTexto").innerHTML = "<p>Não o caralho, tá achando que vai se livrar de mim tão fácil assim? Agora continua aqui.</p>";
            // Simula a continuidade como se fosse "sim"
            setTimeout(function() {
                document.getElementById("mensagemFinalTexto").innerHTML = "<p>Mas antes, quero ter certeza de que é você, então coloque aqui seu nome completo para ver o que acontecerá</p>";
                document.getElementById("inputNome").style.display = "block";
            }, 3000); // Atraso para exibir a mensagem "não" e então prosseguir
        }
    }
}
 
 
// Função para verificar o nome digitado
function verificarNome() {
    var nome = document.getElementById("nomeCompleto").value.trim();
    var nomeCorreto = "Mulher do Cauã Vilela Carvalho";
 
 
    if (nome === nomeCorreto) {
        document.getElementById("avisoErro").innerText = "";
        document.getElementById("inputNome").style.display = "none";
        document.getElementById("imagemFinal").style.display = "block";
    } else {
        tentativasErradas++;
        if (tentativasErradas >= 3) {
            document.getElementById("nomeCompleto").value = nomeCorreto; // Preenche automaticamente
            document.getElementById("avisoErro").innerText = "Vou facilitar pra você, minha gostosa";
            document.getElementById("imagemFinal").style.display = "block";
            document.getElementById("inputNome").style.display = "none";
        } else {
            document.getElementById("avisoErro").innerText = "Nome incorreto, tente novamente.";
        }
    }
}
 
 
// Inicializa a página exibindo a primeira mensagem
document.addEventListener("DOMContentLoaded", function() {
    mudarMensagem(0); // Exibe a primeira mensagem
});