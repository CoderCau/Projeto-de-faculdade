// Função para redirecionar ao clicar no botão
document.getElementById('startBtn').addEventListener('click', function() {

});