    // Função para redirecionar ou atualizar a página
    document.getElementById('nextTipBtn').addEventListener('click', function() {
        location.reload(); // Atualiza a página. Você pode substituir isso para redirecionar para outra página se necessário.
    });