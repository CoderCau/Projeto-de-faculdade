function nextTip() {
    // Aqui você pode colocar a lógica para mudar a dica
    window.location.reload(); // Temporariamente recarregando a página
}