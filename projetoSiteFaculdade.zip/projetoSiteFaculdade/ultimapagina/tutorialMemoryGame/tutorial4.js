document.getElementById("card").addEventListener("click", function() {
    document.getElementById("overlay").style.display = "flex";
    });
    
    document.getElementById("proceedButton").addEventListener("click", function() {
    alert("Redirecionando você para o jogo!");
    });