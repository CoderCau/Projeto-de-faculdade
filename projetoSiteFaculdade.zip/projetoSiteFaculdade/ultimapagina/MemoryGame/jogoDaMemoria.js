const cards = document.querySelectorAll('.card');
const showImagesBtn = document.getElementById('show-images-btn');
const progressBar = document.getElementById('progress-bar');
const finishButton = document.getElementById('finish-button'); // Botão de finalização
const notificationContainer = document.createElement('div'); // Container para notificações
document.body.insertBefore(notificationContainer, document.body.firstChild); // Insere o container no início do body

let matchedPairs = 0;
let blockClick = false; // Variável para bloquear cliques durante notificações
let imagesShown = false; // Para verificar se as imagens já foram mostradas

function createCards() {
    cards.forEach(card => {
        const img = card.querySelector('img');

        card.addEventListener('click', () => {
            if (blockClick) return; // Bloqueia cliques se true

            img.style.opacity = '1'; // Exibe a imagem ao clicar
            img.style.visibility = 'visible'; // Torna a imagem visível
            checkMatch(card);
        });
    });
}

function checkMatch(card) {
    const revealedImages = Array.from(document.querySelectorAll('.card img')).filter(img => img.style.opacity === '1');

    if (revealedImages.length === 2) {
        blockClick = true; // Bloqueia cliques

        if (revealedImages[0].src === revealedImages[1].src) {
            matchedPairs++;
            updateProgress();
            showNotification('success', 'Par encontrado, + 1 pedaço de carta obtido');
            setTimeout(() => {
                revealedImages.forEach(img => {
                    img.parentElement.style.pointerEvents = 'none'; // Desabilita cliques nos pares encontrados
                    img.style.opacity = '0'; // Altera a opacidade para 0
                    img.style.visibility = 'hidden'; // Esconde a imagem
                    img.parentElement.style.backgroundColor = 'transparent'; // Torna o fundo transparente
                });
                blockClick = false; // Libera cliques
            }, 1000);
        }
         else {
            showNotification('error', 'Ops, parece que esse não era o par :(');
            setTimeout(() => {
                revealedImages.forEach(img => {
                    img.style.opacity = '0'; // Altera a opacidade para 0
                    img.style.visibility = 'hidden'; // Esconde as imagens novamente
                });
                blockClick = false; // Libera cliques
            }, 1000);
        }
    }
}

function showNotification(type, message) {
    const notification = document.createElement('div');
    notification.className = type === 'success' ? 'top-notification' : 'error-message';
    notification.innerText = message;
    notificationContainer.appendChild(notification); // Adiciona a notificação ao container

    setTimeout(() => {
        notification.remove(); // Remove a notificação após 2 segundos
    }, 2000);
}

function updateProgress() {
    const progress = (matchedPairs / (cards.length / 2)) * 100; // Atualiza o progresso baseado em pares
    progressBar.style.width = progress + '%';

    if (matchedPairs === cards.length / 2) {
        showFinishButton(); // Mostra o botão de finalização
    }
}

function showFinishButton() {
    finishButton.style.display = 'block';
    finishButton.disabled = true; // Inicialmente desabilitado
    finishButton.style.opacity = 0.5; // Diminui a opacidade
    finishButton.innerText = "Você já encontrou todos os pares, agora espere um pouco para ver a carta.";

    setTimeout(() => {
        finishButton.disabled = false; // Habilita o botão após 5 segundos
        finishButton.style.opacity = 1; // Restaura a opacidade
    }, 5000); // Espera 5 segundos antes de habilitar o botão
}


finishButton.addEventListener('click', () => {
    // Oculta o jogo e exibe o envelope
    document.body.innerHTML = `
        <div class="envelope">
            <div class="ribbon">Clique aqui para abrir</div>
        </div>
        <div class="paper" style="display: none;">
            <p>Sei que estamos completando somente 2 meses juntos, mas nossa história vêm de muito antes desse curto período de tempo, que ainda vai se estender por milênios, pela eternidade, se Deus quiser.
Mesmo quando éramos somente amigos você já me fazia muito bem, embora parecia um carrapato em mim, mas de qualquer jeito, eu sempre gostei disso. Enfim, infelizmente eu demorei a entender que a mulher ideal para mim esteve do meu lado por muito tempo, não sei se era minha burrice ou o meu grau de óculos que estava fazendo eu enxergar errado, mas acredito que era os dois.
Ainda assim, você continuou comigo por MUITO tempo, mesmo quando achava que não daria em nada. Até porque acredito que nenhum de nós dois queria perder o laço forte da nossa amizade.
Depois que terminamos a escola e, com o passar do tempo voltamos a conversar, eu tive um medo do caralho de perder o contato com você, imaginando a possibilidade de você ir para o país dos boludos.
Graças a  Deus, você continuou aqui comigo, e não poderia ser melhor, pois no dia em que a gente se encontrou no parque, um gatilho se ativou em minha cabeça: Eu vou me casar com essa garota, custe oque custar, mas eu vou me casar com ela.
Um pensamento muito avançado para quem não estava nem ao menos namorando com você, não acha? 
E mesmo comigo tentando manter a calma, “pensar melhor”, pela próxima semana e em diante, eu não consegui ficar quieto. Eu me decidi, e cá estamos nós. </p>
<p>Olha minha princesa, eu amei passar cada momento com você até então até esse dia 21/09/2024, um dia depois de completarmos dois meses de namoro. Você fez muito bem para mim recentemente, e eu espero que saiba que eu jamais te deixarei. Sei também que as coisas ficarão mais corriadas daqui para a frente, mas contanto que tenhamos um ao outro, tudo dará certo, pode confiar em mim. E de qualquer jeito, eu não vou abrir mão da minha mulher, pois viveremos juntos até a eternidade. Eu te amo, Brunna.</p>
<p>PS: Esse "site" aqui foi só o começo, ainda vêm muita coisa pela frente.</p>        
</div>
    `;
    
    // Adiciona o evento de clique na fita
    document.querySelector('.ribbon').addEventListener('click', () => {
        document.querySelector('.envelope').style.display = 'none'; // Esconde o envelope
        document.querySelector('.paper').style.display = 'block'; // Mostra a folha de papel
    });
});


showImagesBtn.addEventListener('click', () => {
    if (imagesShown) return; // Bloqueia cliques se as imagens já foram mostradas
    imagesShown = true; // Marca que as imagens foram mostradas

    const allImages = document.querySelectorAll('.card img');
    allImages.forEach(img => {
        img.style.opacity = '1'; // Exibe as imagens
        img.style.visibility = 'visible'; // Torna as imagens visíveis
    });

    setTimeout(() => {
        allImages.forEach(img => {
            img.style.opacity = '0'; // Esconde as imagens novamente
            img.style.visibility = 'hidden'; // Esconde as imagens mantendo o espaço
        });
        showImagesBtn.parentElement.style.display = 'none'; // Oculta o container do botão
    }, 3000);
});

// Cria as cartas ao carregar a página
createCards();

